package es.iescanaveral.dam2.aadd.inm;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import es.iescanaveral.dam2.aadd.inm.utilidades.GestorConfiguracion;

public class GestorFicheros {
	public void imprimirInformnacionConcesionario() {
		String ruta = GestorConfiguracion.getInfoConfiguracion("ruta.ficheros");
		String ficheroXML = GestorConfiguracion.getInfoConfiguracion("fichero.xml.lectura");
		String rutaFichero=ruta+ficheroXML;
		System.out.println(rutaFichero);

		try {
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(rutaFichero);
			  
			NodeList listaNodos=doc.getElementsByTagName("coche");
			for (int i=0; i<listaNodos.getLength();i++) {
				Node nodoCoche= listaNodos.item(i);
				if(nodoCoche.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) nodoCoche;
				
					System.out.println("\nCoche id: " + eElement.getAttribute("id"));
				    System.out.println("Marca: "
				                + eElement.getElementsByTagName("marca").item(0).getTextContent());
				    System.out.println("Modelo: "
				                + eElement.getElementsByTagName("modelo").item(0).getTextContent());
				    System.out.println("Cilindrada: "
				                + eElement.getElementsByTagName("cilindrada").item(0).getTextContent());
				}
			}
		} catch(Exception e) {
			  e.printStackTrace();
		}		
	}
	public void crearDocumentoXML() {
		try {
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			
			//Elemento raíz
			Document doc = docBuilder.newDocument();
			Element rootElement = doc.createElement("modulos");
			doc.appendChild(rootElement);
			//Primer elemento
			Element elemento1 = doc.createElement("modulo");
			rootElement.appendChild(elemento1);
			//Se agrega un atributo ID al nodo elemento y su valor			
			Attr atributo1 = doc.createAttribute("id");
			atributo1.setValue("AAAA");
			elemento1.setAttributeNode(atributo1);

			//Se agrega un atributo NUMERO_HORAS al nodo elemento y su valor			
			Attr atributo2 = doc.createAttribute("numero_horas");
			atributo2.setValue("BBBB");
			elemento1.setAttributeNode(atributo2);

			//Se agrega un atributo CURSO al nodo elemento y su valor			
			Attr atributo3 = doc.createAttribute("curso");
			atributo3.setValue("1");
			elemento1.setAttributeNode(atributo3);

			//Se agrega el elemento TITULO al nodo elemento y su texto			
			Element etiqueta1 = doc.createElement("titulo");
			etiqueta1.setTextContent("Programa CCCCC");
			rootElement.appendChild(etiqueta1);

			//Se agrega el elemento REFERENCIA al nodo elemento y su texto			
			Element etiqueta2 = doc.createElement("referencia");
			etiqueta2.setTextContent("DDDD");
			rootElement.appendChild(etiqueta2);

			//Se escribe el contenido del XML en un archivo
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			DOMSource source = new DOMSource(doc);
			
			String ruta = GestorConfiguracion.getInfoConfiguracion("ruta.ficheros");
			String ficheroXML = GestorConfiguracion.getInfoConfiguracion("fichero.xml.excritura");
			String rutaFichero=ruta+ficheroXML;
			StreamResult result = new StreamResult(new File(rutaFichero));
			transformer.transform(source, result);
	    } catch (ParserConfigurationException pce) {
	      pce.printStackTrace();
	    } catch (TransformerException tfe) {
	      tfe.printStackTrace();
	    }
	}		

}
