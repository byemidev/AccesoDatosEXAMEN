package es.iescanaveral.dam2.aadd.inm;

public class AppPrincipalXML {

	public static void main(String[] args) {
		GestorFicheros gestor = new GestorFicheros();
		gestor.imprimirInformnacionConcesionario();
		
		gestor.crearDocumentoXML();
	}
}
