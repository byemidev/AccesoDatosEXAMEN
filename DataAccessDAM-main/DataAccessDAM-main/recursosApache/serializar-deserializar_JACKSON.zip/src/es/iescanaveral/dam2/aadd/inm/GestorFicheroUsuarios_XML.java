package es.iescanaveral.dam2.aadd.inm;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;

import es.iescanaveral.dam2.aadd.inm.utilidades.GestorConfiguracion;

public class GestorFicheroUsuarios_XML {
	/*
	public void serializarListaAlumnos_XML(List<Alumno> listaAlumnos) {
		try {
			ObjectMapper mapeadorObjetosJackson = new XmlMapper();

			// Serializar un objecto Alumno a un string XML
			String xmlAlumno = mapeadorObjetosJackson.writeValueAsString(listaAlumnos);

			// Mostrar resultado por Consola
			System.out.println(xmlAlumno);

			// Escribir un String XML en un fichero
			String rutaFicheros = GestorConfiguracion.getInfoConfiguracion("ruta.ficheros");
			String nombreFichero = GestorConfiguracion.getInfoConfiguracion("fichero.xml.lectura");
			String nombreRutaFichero = rutaFicheros + nombreFichero;

			Path rutaFichero = Paths.get(nombreRutaFichero);
			Files.writeString(rutaFichero, xmlAlumno, StandardCharsets.UTF_8, StandardOpenOption.CREATE);
		} catch (JsonProcessingException e) {
			// handle exception
		} catch (IOException e) {
			// handle exception
		}
	}
	 */
	public List<UsuarioXML> deserializarListaUsuarios_XML() {
		List<UsuarioXML> listaUsuariosDeserializado = null;
		try {
			ObjectMapper mapeadorObjetosJackson= new XmlMapper();

			// Lectura del fichero XML con información de alumno
			String rutaFicheros = GestorConfiguracion.getInfoConfiguracion("ruta.ficheros");
			String nombreFichero = GestorConfiguracion.getInfoConfiguracion("fichero.xml.lectura");
			String nombreRutaFichero = rutaFicheros + nombreFichero;

			File ficheroXMLUsuarios = new File(nombreRutaFichero);

			// Deserializar el fichero XML y convertirlo en objeto Alumno
			// Paparar un TypeReference para una lista de objetos de tipo Alumno --> List<Alumno>
		    TypeReference<List<UsuarioXML>> tipoListaUsuarios = new TypeReference<List<UsuarioXML>>() {};
		    listaUsuariosDeserializado = mapeadorObjetosJackson.readValue(ficheroXMLUsuarios, tipoListaUsuarios);

		} catch (IOException e) {
			// handle the exception
			e.printStackTrace();
		}
		return listaUsuariosDeserializado;
	}
}
