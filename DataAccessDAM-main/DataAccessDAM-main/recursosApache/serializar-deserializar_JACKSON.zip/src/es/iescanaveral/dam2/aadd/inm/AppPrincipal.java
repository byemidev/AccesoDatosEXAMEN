package es.iescanaveral.dam2.aadd.inm;

import java.util.ArrayList;
import java.util.List;

public class AppPrincipal {

	public static void main(String[] args) {
		// Pruebas de serialización-Deserialización Objetos a XML con JACKSON
		mapearXMLConJackson();
		
		// Pruebas de serialización-Deserialización Objetos a JSON con JACKSON
		mapearJSONConJackson();
		
		// Pruebas de serialización-Deserialización Objetos a JSON con JACKSON
		deserializarUsuariosXMLConJackson();

	}
	private static void mapearXMLConJackson() {
		GestorFicheros_XML gestor = new GestorFicheros_XML();

		// Serializar un alumno con Jackson: Objecto -> Fichero XML
		Alumno alumno =obtenerAlumno();
		gestor.serializarAlumno_XML(alumno);
		
		// Deserializar un fichero XML con Jackson: Fichero XML -> Objeto
		Alumno alumnoDeserializado =gestor.deserializarAlumno_XML();
		System.out.println(alumnoDeserializado);

		List<Alumno> listaAlumnos = obtenerListaAlumnos();
		gestor.serializarListaAlumnos_XML(listaAlumnos);
		
		
		// Deserializar un fichero XML con Jackson: Fichero XML -> List<Objeto>
		List<Alumno> listaAlumnosDeserializados =gestor.deserializarListaAlumnos_XML();
		System.out.println(listaAlumnosDeserializados);
	}
	
	private static void mapearJSONConJackson() {
		GestorFicheros_JSON gestor = new GestorFicheros_JSON();

		// Serializar un alumno con Jackson: Objecto -> Fichero JSON
		Alumno alumno =obtenerAlumno();
		gestor.serializarAlumno_JSON (alumno);
		
		// Deserializar un fichero JSON con Jackson: Fichero JSON -> Objeto
		Alumno alumnoDeserializado =gestor.deserializarAlumno_JSON();
		System.out.println(alumnoDeserializado);

		// Serializar una lista de alumnos
		List<Alumno> listaAlumnos = obtenerListaAlumnos();
		gestor.serializarListaAlumnos_JSON(listaAlumnos);
		
		
		// Deserializar un fichero JSON con Jackson: Fichero JSON -> List<Objeto>
		List<Alumno> listaAlumnosDeserializados =gestor.deserializarListaAlumnos_JSON();
		System.out.println(listaAlumnosDeserializados);
	}

	private static void deserializarUsuariosXMLConJackson() {
		GestorFicheroUsuarios_XML gestor = new GestorFicheroUsuarios_XML();
		
		// Deserializar un fichero XML con Jackson: Fichero XML -> List<Objeto>
		List<UsuarioXML> listaAlumnosDeserializados =gestor.deserializarListaUsuarios_XML();
		System.out.println(listaAlumnosDeserializados);
	}

	private static Alumno obtenerAlumno() {
		Alumno alumno1 = new Alumno();
		alumno1.setId(10);
		alumno1.setNombre("Isabel");
		alumno1.setApellido1("Domínguez");
		alumno1.setApellido2("Salva");
		
		return alumno1;
	}

	private static List<Alumno> obtenerListaAlumnos() {
		List<Alumno> listaAlumnos = new ArrayList<Alumno>();

		Alumno alumno1 = new Alumno();
		alumno1.setId(10);
		alumno1.setNombre("Isabel");
		alumno1.setApellido1("Domínguez");
		alumno1.setApellido2("Salva");
		listaAlumnos.add(alumno1);

		Alumno alumno2 = new Alumno();
		alumno2.setId(10);
		alumno2.setNombre("Carlos");
		alumno2.setApellido1("Maldonado");
		alumno2.setApellido2("Blas");
		listaAlumnos.add(alumno2);

		Alumno alumno3 = new Alumno();
		alumno3.setId(10);
		alumno3.setNombre("Yurena");
		alumno3.setApellido1("Ramiro");
		alumno3.setApellido2("Cos");
		listaAlumnos.add(alumno3);

		return listaAlumnos;
	}
	
	
}
