package es.iescanaveral.dam2.aadd.inm;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import es.iescanaveral.dam2.aadd.inm.utilidades.GestorConfiguracion;

public class GestorFicheros_JSON {
	public void serializarAlumno_JSON (Alumno alumno) {
		try {
			ObjectMapper mapeadorObjetosJackson = new ObjectMapper();

			// Serializar un objecto Alumno a un string JSON
			String jsonAlumno = mapeadorObjetosJackson.writeValueAsString(alumno);

			// Mostrar resultado por Consola
			System.out.println(jsonAlumno);

			// Escribir un String JSON en un fichero
			String rutaFicheros = GestorConfiguracion.getInfoConfiguracion("ruta.ficheros");
			String nombreFichero = GestorConfiguracion.getInfoConfiguracion("ruta.fichero.json.alumno");
			String nombreRutaFichero = rutaFicheros + nombreFichero;

			Path rutaFichero = Paths.get(nombreRutaFichero);
			Files.writeString(rutaFichero, jsonAlumno, StandardCharsets.UTF_8, StandardOpenOption.CREATE);
		} catch (JsonProcessingException e) {
			// handle exception
		} catch (IOException e) {
			// handle exception
		}
	}

	public Alumno deserializarAlumno_JSON() {
		Alumno alumnoDeserializado = null;
		try {
			ObjectMapper mapeadorObjetosJackson = new ObjectMapper();

			// Lectura del fichero JSON con información de alumno
			String rutaFicheros = GestorConfiguracion.getInfoConfiguracion("ruta.ficheros");
			String nombreFichero = GestorConfiguracion.getInfoConfiguracion("ruta.fichero.json.alumno");
			String nombreRutaFichero = rutaFicheros + nombreFichero;

			File ficheroJSONAlumno = new File(nombreRutaFichero);
			alumnoDeserializado = mapeadorObjetosJackson.readValue(ficheroJSONAlumno, Alumno.class);

		} catch (IOException e) {
			// handle the exception
		}
		return alumnoDeserializado;
	}

	public void serializarListaAlumnos_JSON(List<Alumno> listaAlumnos) {
		try {
			ObjectMapper mapeadorObjetosJackson = new ObjectMapper();

			// Serializar un objecto Alumno a un string JSON
			String jsonListaAlumnos = mapeadorObjetosJackson.writeValueAsString(listaAlumnos);

			// Mostrar resultado por Consola
			System.out.println(jsonListaAlumnos);

			// Escribir un String JSON en un fichero
			String rutaFicheros = GestorConfiguracion.getInfoConfiguracion("ruta.ficheros");
			String nombreFichero = GestorConfiguracion.getInfoConfiguracion("ruta.fichero.json.alumnos");
			String nombreRutaFichero = rutaFicheros + nombreFichero;

			Path rutaFichero = Paths.get(nombreRutaFichero);
			Files.writeString(rutaFichero, jsonListaAlumnos, StandardCharsets.UTF_8, StandardOpenOption.CREATE);
		} catch (JsonProcessingException e) {
			// handle exception
		} catch (IOException e) {
			// handle exception
		}
	}

	public List<Alumno> deserializarListaAlumnos_JSON() {
		List<Alumno> listaAlumnosDeserializado = null;
		try {
			ObjectMapper mapeadorObjetosJackson = new ObjectMapper();

			// Lectura del fichero JSON con información de alumno
			String rutaFicheros = GestorConfiguracion.getInfoConfiguracion("ruta.ficheros");
			String nombreFichero = GestorConfiguracion.getInfoConfiguracion("ruta.fichero.json.alumnos");
			String nombreRutaFichero = rutaFicheros + nombreFichero;

			File ficheroJSONAlumnos = new File(nombreRutaFichero);

			// Deserializar el fichero JSON y convertirlo en objeto Alumno
			// Paparar un TypeReference para una lista de objetos de tipo Alumno --> List<Alumno>
		    TypeReference<List<Alumno>> tipoListaAlumnos = new TypeReference<List<Alumno>>() {};

			listaAlumnosDeserializado = mapeadorObjetosJackson.readValue(ficheroJSONAlumnos, tipoListaAlumnos);

		} catch (IOException e) {
			// handle the exception
		}
		return listaAlumnosDeserializado;
	}
}
