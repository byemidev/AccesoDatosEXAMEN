package es.ieselcanaveral.dam2.aadd.geaz.vo;

public class Pais {
	private String cod_pais; 
	private String nombre_pais;
	private String capital;
	private String cod_continente;

	
	public String getCod_continente() {
		return cod_continente;
	}
	public void setCod_continente(String cod_continente) {
		this.cod_continente = cod_continente;
	}
	public String getCod_pais() {
		return cod_pais;
	}
	public void setCod_pais(String cod_pais) {
		this.cod_pais = cod_pais;
	}
	public String getNombre_pais() {
		return nombre_pais;
	}
	public void setNombre_pais(String nombre_pais) {
		this.nombre_pais = nombre_pais;
	}
	public String getCapital() {
		return capital;
	}
	public void setCapital(String capital) {
		this.capital = capital;
	}
	public Pais(String cod_pais, String nombre_pais, String capital, String cod_continente) {
		super();
		this.cod_pais = cod_pais;
		this.nombre_pais = nombre_pais;
		this.capital = capital;
		this.cod_continente = cod_continente;
	}
	@Override
	public String toString() {
		return "Pais [cod_pais=" + cod_pais + ", nombre_pais=" + nombre_pais + ", capital=" + capital
				+ ", cod_continente=" + cod_continente + "]";
	}
}
