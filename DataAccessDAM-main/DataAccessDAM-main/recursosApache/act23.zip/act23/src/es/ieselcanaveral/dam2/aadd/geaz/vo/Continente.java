package es.ieselcanaveral.dam2.aadd.geaz.vo;

public class Continente {
	private String cod_continente; 
	private String nombre_continente;
	public String getCod_continente() {
		return cod_continente;
	}
	public void setCod_continente(String cod_continente) {
		this.cod_continente = cod_continente;
	}
	public String getNombre_continente() {
		return nombre_continente;
	}
	public void setNombre_continente(String nombre_continente) {
		this.nombre_continente = nombre_continente;
	}
	public Continente(String cod_continente, String nombre_continente) {
		super();
		this.cod_continente = cod_continente;
		this.nombre_continente = nombre_continente;
	}
	@Override
	public String toString() {
		return "Continente [cod_continente=" + cod_continente + ", nombre_continente=" + nombre_continente + "]";
	}
	
	
}
