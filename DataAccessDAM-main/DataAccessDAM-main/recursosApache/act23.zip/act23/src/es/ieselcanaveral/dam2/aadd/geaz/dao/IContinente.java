package es.ieselcanaveral.dam2.aadd.geaz.dao;

public interface IContinente {
	public int borrarContinente();
	public int crearContinente();
}
