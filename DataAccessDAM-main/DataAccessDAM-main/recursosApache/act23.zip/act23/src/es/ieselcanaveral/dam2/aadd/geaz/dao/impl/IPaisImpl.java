package es.ieselcanaveral.dam2.aadd.geaz.dao.impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import es.ieselcanaveral.dam2.aadd.geaz.dao.IPais;
import es.ieselcanaveral.dam2.aadd.geaz.vo.Pais;

public class IPaisImpl implements IPais{
	
	private String url = "jdbc:mysql://localhost:3306/"; 
	private String user = "root"; 
	private String psw = "123";
	

	@Override
	public List<Pais> consultarPaisesPorTextoCapital(String codContinente, String inicioCapital) {
		String query = "SELECT * FROM T_PAIS WHERE NOMBRE_PAIS LIKE '"+ codContinente+"' and cod_continente = '"+inicioCapital+"';";
		try{
			Statement  st = this.getConn().createStatement();
			ResultSet rs = st.executeQuery(query);
			while(rs.next()) {
				if(codContinente.equals(rs.getString(0))) {
					String codPais = rs.getString(1);
					String nombrePais= rs.getString(2);
					String capital = rs.getString(3);
					System.out.printf("codigo_continente:%d\n cod_pais:%d\n nombre_pais:%d\n capital:%d\n" , codContinente, codPais, nombrePais, capital);
				}
			}
			st.close();
			rs.close();
			this.getConn().close();
		}catch(SQLException sqle) {
			System.err.println("Error en la conexion en el metodo listar paisesAmericanos" + sqle.getMessage());
		}
		
		return null;
	}

	@Override
	public int actualizarCapital(Pais pais) {
		// TODO Auto-generated method stub 
		return 0;
	}
	
	private Connection  getConn() {
		try(Connection conn = DriverManager.getConnection(url, user, psw)){
			return conn;
		}catch(SQLException sqle) {
			System.err.println("error en obteneer la conexion \n" + sqle.getMessage());
		}
		return null;
	}

}
