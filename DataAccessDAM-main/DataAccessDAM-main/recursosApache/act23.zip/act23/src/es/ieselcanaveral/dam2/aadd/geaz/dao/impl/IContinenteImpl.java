package es.ieselcanaveral.dam2.aadd.geaz.dao.impl;

import es.ieselcanaveral.dam2.aadd.geaz.dao.IContinente;

public class IContinenteImpl implements IContinente {

	@Override
	public int borrarContinente() {
		return 0;
	}

	@Override
	public int crearContinente() {
		return 0;
	}
	
}
