package es.ieselcanaveral.dam2.aadd.geaz.dao;

import java.util.List;

import es.ieselcanaveral.dam2.aadd.geaz.vo.Pais;

public interface IPais {
	public List<Pais> consultarPaisesPorTextoCapital(String codContinente, String inicioCapital);
	public int actualizarCapital(Pais pais);

}
