package es.madrid.redmetro.dao.impl;

public class T_LineaImpl {

}
