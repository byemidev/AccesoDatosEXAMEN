package es.madrid.redmetro.dao.impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import es.madrid.redmetro.geaz.dao.IT_Color;
import es.madrid.redmetro.geaz.vo.T_Color;
import es.madrid.redmetro.geaz.vo.T_Linea;

public class T_ColorImpl implements IT_Color {

	@Override
	public void mostrarinfoColorLinea(int cod_linea) {
		String url = "jdbc:mysql://localhost:3306/red_metro_geaz"; 
		String user = "root"; 
		String psw = "123";
		
		String sql = "SELECT tl.nombre_corto, tl.nombre_largo , tl.kilometros, "
				+ "tc.nombre, tc.cod_hexadecimal FROM T_COLOR tc , T_LINEA tl "
				+ "WHERE tl.cod_linea = tc.cod_linea AND tl.cod_linea = " + cod_linea +";";
		
		try(Connection conn = DriverManager.getConnection(url, user, psw)){
			Statement stm = conn.createStatement();
			ResultSet rs = stm.executeQuery(sql);
			T_Linea linea= new T_Linea();
			//añadir el 
			T_Color color = new T_Color();
			while(rs.next()) {
				linea.setNombre_corto(rs.getString("nombre_corto"));//nombreCorto
				linea.setNombre_largo(rs.getString("nombre_largo"));//nombrelargo
				linea.setKilometros(rs.getFloat("kilometros"));//kilometros
				color.setNombre(rs.getString("nombre"));//nombre
				color.setCod_hexadecimal(rs.getString("cod_hexadecimal"));//cod_hexadecimal
			}
			stm.close();
			rs.close();
			conn.close();
			System.out.printf("El color de la %d (%d) que tiene una longitud de %d Kilómetros es %d (%d). ", linea.getNombre_corto(), linea.getNombre_largo(), linea.getKilometros(), color.getNombre(), color.getCod_hexadecimal());
		}catch(SQLException sqle) {
			System.err.println("error en obteneer la conexion \n" + sqle.getMessage());
		}
	}
	
}
