package es.madrid.redmetro.dao.impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import es.madrid.redmetro.geaz.dao.IT_Cochera;
import es.madrid.redmetro.geaz.gestores.TCocherasCSV;
import es.madrid.redmetro.geaz.vo.T_Cochera;
import es.madrid.redmetro.geaz.vo.T_Color;
import es.madrid.redmetro.geaz.vo.T_Linea;

public class T_CocheraImpl implements IT_Cochera{

	@Override
	public void noHacerNada() {
		System.out.println("Nada que hacer");
	}

	@Override
	public int insertarCochera() {
		
		
		ArrayList<T_Cochera> cocheras  = getCocheras();
		String url = "jdbc:mysql://localhost:3306/red_metro_geaz"; 
		String user = "root"; 
		String psw = "123";
		for(T_Cochera o : cocheras) {
			String sql = "INSERT INTO T_COCHERA (cod_cochera, nombre, direccion, deposito)"
					+ "VALUES (" + o.getCod_cochera() +","+ o.getNombre() +","+o.getDireccion()+","+o.getDeposito()+");";
			try(Connection conn = DriverManager.getConnection(url, user, psw)){
				
				Statement stm = conn.createStatement();
				stm.executeUpdate(sql);
				stm.close();
				conn.close();
				System.out.println("Insertado");
			}catch(SQLException sqle) {
				System.err.println("error en obteneer la conexion \n" + sqle.getMessage());
			}
		}
		return 0;
	}

	@Override
	public int modificarCochera() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int BorrarCochera() {
		// TODO Auto-generated method stub
		return 0;
	}
	
	public ArrayList<T_Cochera> getCocheras(){
		ArrayList<T_Cochera> cocheras = new ArrayList<>();
		TCocherasCSV gestorCocheras = new TCocherasCSV();
		List<String[]> cocherasFromCSV = gestorCocheras.leerCocheraCSV();
		
		for(String[] cocheraData : cocherasFromCSV) {
				int cod_cochera, deposito;
				String nombre, direccion;
				
				cod_cochera = Integer.parseInt(cocheraData[1]);
				nombre = cocheraData[3];
				direccion = cocheraData[4];
				deposito = Integer.parseInt(cocheraData[2]);
				cocheras.add(new T_Cochera(cod_cochera,nombre,direccion,deposito));
		}
		
		return cocheras;
	}

}
