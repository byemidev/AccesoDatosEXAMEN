package es.madrid.redmetro.geaz;
import es.madrid.redmetro.dao.impl.T_ColorImpl;
import es.madrid.redmetro.dao.impl.T_CocheraImpl;
import es.madrid.redmetro.geaz.dao.IT_Color;
import es.madrid.redmetro.geaz.dao.IT_Cochera;

import java.util.Scanner;

public class AppMain {
	static Scanner sc = new Scanner(System.in);
	
	public static void main(String []args) {
	
	System.out.println("PROGRAMA RED METRO");
	String input = sc.nextLine();
	introducirOpcion((input.toUpperCase()).charAt(0));
	}
	//switch case main como metodo statico
	public static void introducirOpcion(char opcion) {
		switch(opcion) {
		case 'A':
			System.out.println("has elegido la opcion A");
			IT_Color color = new T_ColorImpl();
			int cod_linea = 13;
			// obtendrá Información asociada a color de una línea
			color.mostrarinfoColorLinea(cod_linea);
			//con errores de compilacion. 
			break;
		case 'B':
			System.out.println("has elegido la opcion B");
			//TODO
			break;
		case 'C':
			System.out.println("Elige una de las siguientes opciones: "
					+ "\n0 - no hacer nada"
					+ "\n1 - insertar cochera"
					+ "\n2 - modificar cochera"
					+ "\n3 - Borrar cochera"
					+ "");
			int opcionB = sc.nextInt();
			IT_Cochera cochera = new T_CocheraImpl();
			cochera.insertarCochera();
			
			//con errores de compilacion
				switch(opcionB) {
				case 0: 
					System.out.println("no haremos nada");
					break;
					
				case 1: 
					System.out.println("Insertamos cochera");
					break;
				case 2: 
					System.out.println("Modificamos cochera");
					break;
					
				case 3: 
					System.out.println("Eliminamos cochera");
					break;
				}
		break;
		case 'D':
			break;
		}
	}
}
