package es.madrid.redmetro.geaz.gestores;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;
import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvException;

public class TCocherasCSV{
	public TCocherasCSV() {}
	public List<String[]>  leerCocheraCSV() {
		try{
			File csv = new File("/home/dam2aadd/eclipse-workspace/RedMetroGEAZ/bin/cocherasRM.csv");
			CSVReader csvReader = new CSVReader(new FileReader(csv));
			List<String[]> datos = csvReader.readAll();
			return datos;
		}catch(IOException | CsvException fe) {
			System.err.println("error fichero csv no existe" + fe.getMessage());
			System.err.println("error IO --_>>> \n");
		}
		return null;
	}
}
