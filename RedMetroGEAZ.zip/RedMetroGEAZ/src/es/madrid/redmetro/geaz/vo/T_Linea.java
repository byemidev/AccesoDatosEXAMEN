package es.madrid.redmetro.geaz.vo;

public class T_Linea {
	private int cod_linea;
	private String nombre_corto, nombre_largo;
	private float kilometros;
	public int getCod_linea() {
		return cod_linea;
	}
	public void setCod_linea(int cod_linea) {
		this.cod_linea = cod_linea;
	}
	public String getNombre_corto() {
		return nombre_corto;
	}
	public void setNombre_corto(String nombre_corto) {
		this.nombre_corto = nombre_corto;
	}
	public String getNombre_largo() {
		return nombre_largo;
	}
	public void setNombre_largo(String nombre_largo) {
		this.nombre_largo = nombre_largo;
	}
	public float getKilometros() {
		return kilometros;
	}
	public void setKilometros(float kilometros) {
		this.kilometros = kilometros;
	}
	public T_Linea(int cod_linea, String nombre_corto, String nombre_largo, float kilometros) {
		super();
		this.cod_linea = cod_linea;
		this.nombre_corto = nombre_corto;
		this.nombre_largo = nombre_largo;
		this.kilometros = kilometros;
	}
	
	
	public T_Linea() {
		//constructor vacio
	}
	@Override
	public String toString() {
		return "T_Linea [cod_linea=" + cod_linea + ", nombre_corto=" + nombre_corto + ", nombre_largo=" + nombre_largo
				+ ", kilometros=" + kilometros + "]";
	}
}
