package es.madrid.redmetro.geaz.vo;

public class T_Tren {
	
}
