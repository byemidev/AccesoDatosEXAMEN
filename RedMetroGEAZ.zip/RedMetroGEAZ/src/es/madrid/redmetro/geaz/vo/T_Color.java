package es.madrid.redmetro.geaz.vo;

public class T_Color {
	private String  nombre, cod_hexadecimal;
	private int cod_linea;
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getCod_hexadecimal() {
		return cod_hexadecimal;
	}
	public void setCod_hexadecimal(String cod_hezagecimal) {
		this.cod_hexadecimal = cod_hezagecimal;
	}
	public int getCod_linea() {
		return cod_linea;
	}
	public void setCod_linea(int cod_linea) {
		this.cod_linea = cod_linea;
	}
	public T_Color(String nombre, String cod_hezagecimal, int cod_linea) {
		super();
		this.nombre = nombre;
		this.cod_hexadecimal = cod_hezagecimal;
		this.cod_linea = cod_linea;
	}
	public T_Color() {
		//constructor vacio
	}
	
	@Override
	public String toString() {
		return "T_Color [nombre=" + nombre + ", cod_hezagecimal=" + cod_hexadecimal + ", cod_linea=" + cod_linea + "]";
	}
}
