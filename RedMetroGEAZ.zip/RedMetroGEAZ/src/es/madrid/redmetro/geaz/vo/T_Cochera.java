package es.madrid.redmetro.geaz.vo;

public class T_Cochera {
	
	private int cod_cochera, deposito;
	private String nombre, direccion;
	
	
	public int getCod_cochera() {
		return cod_cochera;
	}
	public void setCod_cochera(int cod_cochera) {
		this.cod_cochera = cod_cochera;
	}
	public int getDeposito() {
		return deposito;
	}
	public void setDeposito(int deposito) {
		this.deposito = deposito;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getDireccion() {
		return direccion;
	}
	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}
	public T_Cochera(int cod_cochera, String nombre, String direccion, int deposito) {
		super();
		this.cod_cochera = cod_cochera;
		this.deposito = deposito;
		this.nombre = nombre;
		this.direccion = direccion;
	}
}	
