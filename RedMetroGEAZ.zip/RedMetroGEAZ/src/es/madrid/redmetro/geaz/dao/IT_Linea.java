package es.madrid.redmetro.geaz.dao;

public interface IT_Linea {

}
