package es.madrid.redmetro.geaz.dao;

public interface IT_Color {
	 void mostrarinfoColorLinea(int cod_linea);
}
