package es.madrid.redmetro.geaz.dao;
import es.madrid.redmetro.geaz.vo.T_Cochera;
public interface IT_Cochera {
	void noHacerNada();
	int modificarCochera();
	int BorrarCochera();
	int insertarCochera();
}
